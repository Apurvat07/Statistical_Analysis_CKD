data<-read.csv("/Users/liuchenyang/Desktop/STAT 630/Group Project/casestudydata.csv")
data
out_sample=which(is.na(data$CKD)==1)
data_out=data[out_sample,]  
data_in=data[-out_sample,]

# Q1
 # Choosing factors as few as possible for the prediction result of CKD as accurate as possible.


# Q2
  summary(data)
  # summary
  summary(data_in) # how to deal with income may be a problem: 1166 missing but may have meaning; missing CKD are for prediction!
  dim(data_in)
  data_in_2=na.omit(data_in)
  dim(data_in_2)
  # 4136/6000 patients;
  # 23 vs. 11 (top3:Income>PoorVision>Unmarried; bottom3:Diabetes<Anemia<Stroke)
  # problem of missing values in regression: The missing values might be important for a regression-type analysis. Since the mathematics of regression is based on the minimized loss function, an outlier can have a big influence on the slope of a line. Consequently, the coefficient will change in the regression model. Which means, if these values are missing randomly, the result of regression might not change a lot. However, if the values are missing because of a specific reason, the result of the regression would be influenced to a relatively large extent.
  
  
# Q3
 names(data_in)
 data_q3<-data_in[,c(27,25,21,29,30,32,26,28,2,4)]
 data_q3$CD<-ifelse(data_q3$PVD==1,1,ifelse(data_q3$Stroke==1,1,ifelse(data_q3$CVD==1,1,ifelse(data_q3$CHF==1,1,0)))) 
 data_q3$FAM<-ifelse(data_q3$Fam.Hypertension==1,1,ifelse(data_q3$Fam.Diabetes==1,1,0)) 
 data_q3_2<-data_q3[,-c(3:8)] 
 data_q3_2$CKD<-data_in[,c(34)]
 df3<-data_q3_2 
 cor(df3$Diabetes,df3$CKD,use="complete.obs") 
 cor(df3$Hypertension,df3$CKD,use="complete.obs") 
 cor(df3$CD,df3$CKD,use="complete.obs") 
 cor(df3$FAM,df3$CKD,use="complete.obs")   # against expectation!!!
 cor(df3$Age,df3$CKD,use="complete.obs") 
 race<-xtabs(~CKD+Racegrp,data=df3)   # chi-square?
 
 
# Q4
 df4<-data_in[,-c(4,8,)]
 correlation<-cor(df4,use="complete.obs")
 write.csv(correlation, "/Users/liuchenyang/Desktop/STAT 630/Group Project/correlation.csv")
 correlation<-correlation[correlation>=0.75|correlation<=-0.75]
 correlation<-correlation[correlation!=1]
 unique(correlation)  
 # 6 highly correlated (>=0.75): "Weight & BMI", "Weight & Waist", "BMI & Waist", "LDL & Total.Chol", "Fam.Hyptertension & Fam.Diabetes"
 # Multicollinearity: Multillinearity arises when investigators include predictors carrying redundant information in the model. A symptom is a model with a high R-Square, showing that collectively the predictors bear heavily on the response, but paradoxically, few or none of the predictors have regression coefficients significantly different from zero.A consequence of multicollinearity is the inability to estimate the model’s regression coefficients with acceptable precision. Therefore, models with this problem are not considered useful. It is unacceptable to reach a final model that has this condition to an appreciable extent. 
 # When this happens, the points can be fitted fairly well by any plane containing this straight line. Since each of these many planes is a candidate for the best model, the model decided upon as being the best will be similar to other model candidates. Therefore, declaring any model to be best will be a tentative decision. This tentativeness is expressed by large standard errors of the estimated regression coefficients that comprise the coefficients of the plane corresponding to the best model.
 
 
 # Q5
 data_new=model.matrix(~-1+Racegrp+CareSource,data=data_in) 
 head(data_new)
 summary(data_new)
 data_in=data_in[,-c(1,4,8)] 
 data_in=cbind(data_in,data_new)
 cor(data_in)
 names(data_in)
 data_in=data_in[,-33]
 model=lm(CKD~.,data=data_in)
 summary(model)
 # Based on the p-values, there are some variables which don't have a signifianct influence on the regression model, such as CareSource.
 # Based on the value of the coefficient, the result is conflict. For example, BMI and weight are a highly related. But the coeffcient of weight means that if someone is weighter then he/she has a higher posibility of getting CKD. However, the coefficient of BMI means that if someone has a higher BMI, he/she is less likely to have CKD.
 # Based on all the expression of regression, the value of a prediction can be negative or more than 1. This makes no sense. 
 
 
# Q6
 # continous: Age, Weight, Height, BMI, Waist, SBP, DBP, HDL, LDL, Total.Chol, Activity
 
 
 