df<-read.csv("/Users/liuchenyang/Desktop/STAT 630/Group Project/casestudydata.csv")
out_sample=which(is.na(data$CKD)==1)
data_out=data[out_sample,]  
data_in=data[-out_sample,]

# Q1



# Q2
summary(data) 
dim(data)


# Q3
df1=model.matrix(~-1+Racegrp+CareSource,data=df)
df2<-cbind(df,df1)
df2<-df2[,-c(4,8)]
names(df2)
df3<-df2[,c(25,23,19,27,28,30,2)]
names(df3)
df3<-cbind(df3,df1)
df3$CD<-ifelse(df3$PVD==1,1,ifelse(df3$Stroke==1,1,ifelse(df3$CVD==1,1,ifelse(df3$CHF==1,1,0)))) 
df3<-df3[,-c(3:6)]
df3$CKD<-df2$CKD
cor(df3,use="complete.obs")

check<-df3
check$Stroke<-df$Stroke
check$CVD<-df$CVD
check$CHF<-df$CHF
check$PVD<-df$PVD
check$CK<-ifelse(check$Stroke==1,1,ifelse(check$CVD==1,1,ifelse(check$CHF==1,1,0)))
sum(check$CK,na.rm = TRUE)
sum(check$CVD,na.rm = TRUE)


# Q4
df4<-cbind(df1,df)
df4<-df4[,-c(12,16)]
correlation<-cor(df4,use="complete.obs")
View(correlation)
write.csv(correlation,"/Users/liuchenyang/Desktop/STAT 630/Group Project/q4_correlation.csv")

# Q6
out_sample=which(is.na(df4$CKD)==1)
df_out=df4[out_sample,]  
df_in=df4[-out_sample,]

lm1<-lm(data=df_in,CKD~.)
summary(lm1)

lm2<-lm(data=df_in,CKD~Age+Hypertension+CVD+PVD+Diabetes+CHF+Insured+PoorVision+Racegrpwhite+CareSourceDrHMO+Smoker+Unmarried+LDL+Obese+Anemia+Fam.Diabetes+Female+CareSourceclinic+Racegrpother+Height+Fam.Hypertension+HDL+DBP+Fam.CVD+Educ+CareSourcenoplace+Income+Racegrphispa+Activity)
summary(lm2)

lm3<-lm(data=df_in,CKD~Age+Hypertension+CVD+PVD+Diabetes+CHF+Racegrpwhite+Unmarried+Anemia+Fam.Diabetes+Female+HDL+DBP+Racegrphispa+Activity)
summary(lm3)

lm4<-lm(data=df_in,CKD~Age+Hypertension+CVD+PVD+Diabetes+CHF+Racegrpwhite+Unmarried+Anemia+Female+HDL+DBP+Racegrphispa+Activity)
summary(lm4)


