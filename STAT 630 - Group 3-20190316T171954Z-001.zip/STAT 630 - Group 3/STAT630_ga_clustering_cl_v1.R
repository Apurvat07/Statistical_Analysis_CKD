df<-read.csv("/Users/liuchenyang/Desktop/STAT 630/Group Project/CleanData2.csv")

train_test<-which(is.na(df$CKD)==1)
test<-df[train_test,]
train<-df[-train_test,]
train_1<-which(train$CKD==1)
train_1<-train[train_1,]
train_0<-which(train$CKD==0)
train_0<-train[train_0,]

# STANDARDIZE OR NOT
# very important ratio variables: Age
# very important dummy variables: Heart, Diabetes, Hypertension, Anemia (>0.1)

plot(train$Age,train$CKD) # most important factor!!!
hist(train$Age)

f1<-which(train$Female==1&train$CKD==1) # 254
f0<-which(train$Female==1&train$CKD==0) # 2881
m1<-which(train$Female==0&train$CKD==1) # 210
m0<-which(train$Female==0&train$CKD==0) # # 2655
length(f1)/(length(f0)+length(f1))-length(m1)/(length(m0)+length(m1)) # 0.008

plot(train$DBP,train$CKD)
hist(train$DBP)

plot(train$LDL,train$CKD)
hist(train$LDL)

s11<-which(train$Smoker==1&train$CKD==1) 
s10<-which(train$Smoker==1&train$CKD==0)
s01<-which(train$Smoker==0&train$CKD==1) 
s00<-which(train$Smoker==0&train$CKD==0) 
length(s11)/(length(s10)+length(s11))-length(s01)/(length(s00)+length(s01)) # 0.039

d11<-which(train$Diabetes==1&train$CKD==1) 
d10<-which(train$Diabetes==1&train$CKD==0) 
d01<-which(train$Diabetes==0&train$CKD==1) 
d00<-which(train$Diabetes==0&train$CKD==0) 
length(d11)/(length(d10)+length(d11))-length(d01)/(length(d00)+length(d01)) # 0.132

h11<-which(train$Hypertension==1&train$CKD==1) 
h10<-which(train$Hypertension==1&train$CKD==0) 
h01<-which(train$Hypertension==0&train$CKD==1)
h00<-which(train$Hypertension==0&train$CKD==0) 
length(h11)/(length(h10)+length(h11))-length(h01)/(length(h00)+length(h01)) # 0.128

a11<-which(train$Anemia==1&train$CKD==1) 
a10<-which(train$Anemia==1&train$CKD==0) 
a01<-which(train$Anemia==0&train$CKD==1)
a00<-which(train$Anemia==0&train$CKD==0) 
length(a11)/(length(a10)+length(a11))-length(a01)/(length(a00)+length(a01)) # 0.107

plot(train$SBP,train$CKD)
hist(train$SBP)
cor(train$SBP,train$CKD)

r11<-which(train$race==1&train$CKD==1) 
r10<-which(train$race==1&train$CKD==0) 
r01<-which(train$race==0&train$CKD==1)
r00<-which(train$race==0&train$CKD==0) 
length(r11)/(length(r10)+length(r11))-length(r01)/(length(r00)+length(r01)) # 0.003

o11<-which(train$Obese==1&train$CKD==1) 
o10<-which(train$Obese==1&train$CKD==0) 
o01<-which(train$Obese==0&train$CKD==1)
o00<-which(train$Obese==0&train$CKD==0) 
length(o11)/(length(o10)+length(o11))-length(o01)/(length(o00)+length(o01)) # -0.001

ha11<-which(train$Heart==1&train$CKD==1) 
ha10<-which(train$Heart==1&train$CKD==0) 
ha01<-which(train$Heart==0&train$CKD==1)
ha00<-which(train$Heart==0&train$CKD==0) 
length(ha11)/(length(ha10)+length(ha11))-length(ha01)/(length(ha00)+length(ha01)) # 0.242

library(flexclust) 
# UNSTANDARDIZED
  df1<-train_1[,-13]
  cor_1<-round(cor(df1),2)
  hc_df1<-hclust(dist(df1),"single")
  plot(hc_df1,main="single")                   # no
  hc_df1<-hclust(dist(df1),"centroid")
  plot(hc_df1,main="centroid")                 # no
  hc_df1<-hclust(dist(df1),"complete")
  plot(hc_df1,main="complete")                 # no
  hc_df1<-hclust(dist(df1),"average")
  plot(hc_df1,main="average")                  # no
  hc_df1<-hclust(dist(df1),"ward.D")
  plot(hc_df1,main="Ward's")                   # yes
  tss<-rep(0,20)
  for (k in 1:20){tss[k]=kmeans(df1,k)$tot.withinss}
  plot(1:20,tss)
  points(5,tss[5],pch=16,col="red")
  cl=kmeans(df1,5) 
  cl
  plot(df1, col = cl$cluster)
  cl$centers
  # 1 - 
  # 2 - old, low LDL
  # 3 - young, low SBP
  # 4 - high LDL
  # 5 - high SBP
  
  df0<-train_0[,-13]
  cor_<-round(cor(df0),2)
  hc_df0<-hclust(dist(df0),"single")           
  plot(hc_df0,main="single")                   # no
  hc_df0<-hclust(dist(df0),"centroid")
  plot(hc_df0,main="centroid")                 # no
  hc_df0<-hclust(dist(df0),"complete")
  plot(hc_df0,main="complete")                 # yes
  hc_df0<-hclust(dist(df0),"average")
  plot(hc_df0,main="average")                  # no
  hc_df0<-hclust(dist(df0),"ward.D")
  plot(hc_df0,main="Ward's")                   # no
  tss<-rep(0,20)
  for (k in 1:20){tss[k]=kmeans(df0,k)$tot.withinss}
  plot(1:20,tss)
  points(5,tss[5],pch=16,col="red")
  cl=kmeans(df0,5) 
  cl
  plot(df0, col = cl$cluster)
  cl$centers
  # 1 - young, low DBP, low LDL
  # 2 - old, high SBP
  # 3 - young
  # 4 - high LDL, high SBP
  # 5 - 


# STANDARDIZED
  train_1<-scale(train_1)
  train_0<-scale(train_0)
  df1<-train_1[,-13]
  cor_1<-round(cor(df1),2)
  hc_df1<-hclust(dist(df1),"single")
  plot(hc_df1,main="single")                   # no
  hc_df1<-hclust(dist(df1),"centroid")
  plot(hc_df1,main="centroid")                 # no
  hc_df1<-hclust(dist(df1),"complete")
  plot(hc_df1,main="complete")                 # no
  hc_df1<-hclust(dist(df1),"average")
  plot(hc_df1,main="average")                  # no
  hc_df1<-hclust(dist(df1),"ward.D")
  plot(hc_df1,main="Ward's")                   # yes
  tss<-rep(0,20)
  for (k in 1:20){tss[k]=kmeans(df1,k)$tot.withinss}
  plot(1:20,tss)
  points(10,tss[10],pch=16,col="red")
  cl=kmeans(df1,10) 
  cl
  plot(df1, col = cl$cluster)
  cl$centers
  # 1 - obsese female
  # 2 - diabetes
  # 3 - DBP, LDL, diabetes
  # 4 - 
  # 5 - heart
  # 6 - SBP
  # 7 - lower hypertension
  # 8 - obsese male
  # 9 - anemia
  # 10 - low hypertension
  
  df0<-train_0[,-13]
  cor_<-round(cor(df0),2)
  hc_df0<-hclust(dist(df0),"single")           
  plot(hc_df0,main="single")                   # no
  hc_df0<-hclust(dist(df0),"centroid")
  plot(hc_df0,main="centroid")                 # no
  hc_df0<-hclust(dist(df0),"complete")
  plot(hc_df0,main="complete")                 # no
  hc_df0<-hclust(dist(df0),"average")
  plot(hc_df0,main="average")                  # no
  hc_df0<-hclust(dist(df0),"ward.D")
  plot(hc_df0,main="Ward's")                   # yes
  tss<-rep(0,20)
  for (k in 1:20){tss[k]=kmeans(df0,k)$tot.withinss}
  plot(1:20,tss)
  points(10,tss[10],pch=16,col="red")
  cl=kmeans(df0,10) 
  cl
  plot(df0, col = cl$cluster)
  cl$centers
  # 1 - female, non-black
  # 2 - diabetes
  # 3 - male, smoker
  # 4 - old, heart
  # 5 - obsese
  # 6 - anemia
  # 7 - female, black
  # 8 - male
  # 9 - hypertension, sbp
  # 10 - female, smoker
  
