df_lm
cor(df_lm)
w1 = lm(Weight~Diabetes+Age+CVD+PVD+CHF+Insured+PoorVision+Racegrpwhite+Racegrpblack+Racegrphispa+Racegrpother+Smoker+Unmarried+LDL+Obese+Anemia+Fam.Diabetes+Female+Height+Fam.Hypertension+HDL+DBP+Fam.CVD+Educ+Income+Activity, data=df_lm, y=TRUE)
summary(w1)
w2 = lm(Weight~Diabetes+Racegrpblack+Racegrphispa+Smoker+LDL+Obese+Fam.Diabetes+Female+Height+HDL+DBP+Fam.CVD+Activity, data=df_lm, y=TRUE)
summary(w2)
predict_w<-predict.lm(w2,data.frame(df_lm_test))
predict_w
predict_w<-as.data.frame(predict_w)
summary(df)
comp_w<-df[8001:8819,7]
comp_w
actuals_preds <- data.frame(cbind(actuals=comp_w, predicteds=predict_w))
actuals_preds
actuals_preds<-na.omit(actuals_preds)
correlation_accuracy <- cor(actuals_preds)
correlation_accuracy
min_max_accuracy <- mean(apply(actuals_preds, 1, min) / apply(actuals_preds, 1, max))  
min_max_accuracy
predict_w