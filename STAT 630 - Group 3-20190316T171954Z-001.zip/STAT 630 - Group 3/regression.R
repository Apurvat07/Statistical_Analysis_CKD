##logistic regression##;
setwd("C:/Users/anqiw/Desktop/2019 winter/multivariates/project")
data=read.csv("CleanData2.csv")
names(data)


##regression##
#class(data)
summary(data)
data_out=data[which(is.na(data$CKD)==1), ]  
data_in=data[which(is.na(data$CKD)==0), ]  
data
#0.05 level significant##
r<-glm(data=data_in,CKD~Age+Female+DBP+LDL+Smoker+Diabetes+Hypertension+Anemia+SBP+race+Obese+Heart, family = binomial(link = "logit"))
summary(r)

r2<-glm(data=data_in,CKD~Age+Female+LDL+Diabetes+Hypertension+Anemia+SBP+Heart, family = binomial(link = "logit"))
summary(r2)

r3<-glm(data=data_in,CKD~Age+LDL+Diabetes+Hypertension+Anemia+SBP+Heart, family = binomial(link = "logit"))
summary(r3)


#0.001 level#
r4<-glm(data=data_in,CKD~Age+Diabetes+Hypertension+Anemia+Heart, family = binomial(link = "logit"))
summary(r4)

#predict_r=predict.glm(r,data.frame(data_out), type = "response")
#predict<-data.frame(predict_r)

#write.csv(predict, file = "predict2.csv")
