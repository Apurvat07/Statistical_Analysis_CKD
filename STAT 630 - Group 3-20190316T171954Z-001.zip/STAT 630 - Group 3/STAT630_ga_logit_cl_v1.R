df<-read.csv("/Users/liuchenyang/Desktop/STAT 630/casestudydata.csv")

# 3 key factors with missings: Diabetes=2, Hypertention=80, CVD=23
# fam.CVD isn't considered bc the result of regression has shown insignificant influence
df1=model.matrix(~-1+Racegrp,data=df)
df<-cbind(df,df1)
df<-df[,-c(1,4,8,34)]
summary(df) 
df_lm<-df[1:8000,]
df_lm_test<-df[8001:8819,]
df_lm_test[is.na(df_lm_test)]<-0
df_lm_test<-as.data.frame(df_lm_test)

# Diabetes
d1<-glm(data=df_lm,Diabetes~Age+Hypertension+CVD+PVD+CHF+Insured+PoorVision+Racegrpwhite+Racegrpblack+Racegrphispa+Racegrpother+Smoker+Unmarried+LDL+Obese+Anemia+Fam.Diabetes+Female+Height+Fam.Hypertension+HDL+DBP+Fam.CVD+Educ+Income+Activity,family = "binomial")
summary(d1)
d2<-glm(data=df_lm,Diabetes~Age+Hypertension+PVD+Racegrpwhite+Obese+Fam.Diabetes+HDL+DBP+Activity,family = "binomial")
summary(d2)
predict_d<-predict.glm(d2,data.frame(df_lm_test))
predict_d<-as.data.frame(predict_d)
prob <- exp(predict_d)/(1+exp(predict_d))
prob$prob<-ifelse(prob>0.5,1,0)
prob<-as.data.frame(prob)
comp_d<-df[8001:8819,26]
comp_d<-cbind(prob,comp_d)
comp_d<-as.data.frame(comp_d)
comp_d$result<-ifelse(comp_d$prob==1&comp_d$comp_d==1,0,ifelse(comp_d$prob==0&comp_d$comp_d==0,0,1))
comp_d$result<-as.numeric(comp_d$result)
comp_d<-na.omit(comp_d)
accuracy_d<-round((1-sum(comp_d$result)/nrow(comp_d))*100,2)
accuracy_d

# Hypertension
h1<-glm(data=df_lm,Hypertension~Diabetes+Age+CVD+PVD+CHF+Insured+PoorVision+Racegrpwhite+Racegrpblack+Racegrphispa+Racegrpother+Smoker+Unmarried+LDL+Obese+Anemia+Fam.Diabetes+Female+Height+Fam.Hypertension+HDL+DBP+Fam.CVD+Educ+Income+Activity,family = "binomial")
summary(h1)
h2<-glm(data=df_lm,Hypertension~Diabetes+Age+CVD+PVD+CHF+Insured+Racegrpblack+Unmarried+Obese+Female+Fam.Hypertension+DBP+Fam.CVD+Educ,family = "binomial")
summary(h2)
predict_h<-predict.glm(h2,data.frame(df_lm_test))
predict_h<-as.data.frame(predict_h)
prob_h <- exp(predict_h)/(1+exp(predict_h))
prob_h$prob<-ifelse(prob_h>0.5,1,0)
prob_h<-prob_h[,-1]
prob_h<-as.data.frame(prob_h)
comp_h<-df[8001:8819,22]
comp_h<-cbind(prob_h,comp_h)
comp_h<-as.data.frame(comp_h)
comp_h$result<-ifelse(comp_h$predict_h==1&comp_h$comp_h==1,0,ifelse(comp_h$predict_h==0&comp_h$comp_h==0,0,1))
comp_h$result<-as.numeric(comp_h$result)
comp_h<-na.omit(comp_h)
accuracy_h<-round((1-sum(comp_h$result)/nrow(comp_h))*100,2)
accuracy_h


# CVD
c1<-glm(data=df_lm,CVD~Hypertension+Diabetes+Age+PVD+CHF+Insured+PoorVision+Racegrpwhite+Racegrpblack+Racegrphispa+Racegrpother+Smoker+Unmarried+LDL+Obese+Anemia+Fam.Diabetes+Female+Height+Fam.Hypertension+HDL+DBP+Fam.CVD+Educ+Income+Activity,family = "binomial")
summary(c1)
c2<-glm(data=df_lm,CVD~Hypertension+Age+CHF+Racegrphispa+Female+HDL+Fam.CVD+Income+Activity,family = "binomial")
summary(c2)
predict_c<-predict.glm(c2,data.frame(df_lm_test))
predict_c<-as.data.frame(predict_c)
prob_c <- exp(predict_c)/(1+exp(predict_c))
prob_c$prob<-ifelse(prob_c>0.5,1,0)
prob_c<-prob_c[,-1]
prob_c<-as.data.frame(prob_c)
comp_c<-df[8001:8819,27]
comp_c<-cbind(prob_c,comp_c)
comp_c<-as.data.frame(comp_c)
comp_c$result<-ifelse(comp_c$predict_c==1&comp_c$comp_c==1,0,ifelse(comp_c$predict_c==0&comp_c$comp_c==0,0,1))
comp_c$result<-as.numeric(comp_c$result)
comp_c<-na.omit(comp_c)
accuracy_c<-round((1-sum(comp_c$result)/nrow(comp_c))*100,2)
accuracy_c
