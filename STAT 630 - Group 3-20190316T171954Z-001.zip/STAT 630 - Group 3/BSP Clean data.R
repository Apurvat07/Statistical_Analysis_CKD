data=read.csv("casestudydata.csv")
names(data)
data=data[,-c(1,34)] 
data

#class(data)
summary(data)
data_out=data[8001:8819,]  
data_in=data[1:8000,]   
data
data_out=na.omit(data_out)
r<-lm(data=data_in,SBP~Age+Hypertension+CVD+PVD+CHF+Insured+PoorVision+Smoker+Unmarried+LDL+Obese+Anemia+Fam.Diabetes+Female+Height+Fam.Hypertension+HDL+DBP+Fam.CVD+Educ+Income+Activity)
summary(r)
y=predict.lm(r,data.frame(data_in))
predict_r=predict.lm(r,data.frame(data_out))
com_SBP=data_out[,14]
accracy=cor(predict_r,com_SBP)
SBP =data[,14]
predict_r
SBP1=predict.lm(r,data.frame(data))
SBP1
SBP1=data.frame(upd)
data=data.frame(data)
comp=cbind(SBP,SBP1)
comp
comp[is.na(comp[,2]),2] <- mean(comp[,2], na.rm = TRUE)
comp
for (i in 1:8819) {
  if (is.na(comp[i,1])){
    comp[i,1]<-comp[i,2]
  }  
}
comp
colSums(is.na(comp))

